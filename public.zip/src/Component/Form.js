import React from 'react'
import {useState} from "react"
const Form = () => {

    const [Data, setData] = useState({
        username:"",
        email:"",
        Games:"",
        ACHIVE:"",
        Playerlevel:[]
      })
      
      
      const handleChange = (e) => {
        
        console.log(e)
      
        if(e.target.name == 'Playerlevel') {
           let copy = {...Data}
           
           if(e.target.checked){
           copy.Playerlevel.push(e.target.value)
          }
          setData(copy)
        
          } else{
          setData(()=>({
            ...Data,
            [e.target.name] : e.target.value
           }))
         }
        
      }
      
      const HandleSubmit = (e) => {
        e.preventDefault()
        console.log(Data)
      }

  return (
    <>
     <form onSubmit={HandleSubmit}>
        <input type="text"  onChange={handleChange} name='username' placeholder="Name" /><br></br>
        <input type="email" onChange={handleChange}  name='email' placeholder="Email" /><br></br>

        <label htmlFor='Games'>Games<br/>
        <select name='Games' onChange={handleChange}>
          <option value="Pubg" >Pubg</option>
          <option value="Cricket">Cricket</option>
          <option value="NFS" > NFS</option>
          <option value="GTA" >GTA</option>
        </select>
        </label>
        <br/>
        <label htmlFor='Player-Level'> Playerlevel <br/> </label>
         <input type="checkbox" onChange={handleChange} name="Playerlevel" value="Expert" />
             <label htmlFor="Expert">Expert</label>
         <br/>
         <input type="checkbox" onChange={handleChange} name="Playerlevel" value="Intermidiete"/>
         <label htmlFor="Intermidiete">Intermidiete</label>
         <br/>
         <input type="checkbox" onChange={handleChange} name="Playerlevel" value="Beginar"/>
         <label htmlFor="Beginar">Beginar</label>
         
         <br/>

         <label htmlFor='ACHIVE' >ACHIVE<br/>
         <input type="radio" onChange={handleChange} name='ACHIVE'  value="Bronze" /> Bronze
         <br/>
         <input type="radio" onChange={handleChange} name='ACHIVE' value="silver"/> silver
         <br/>
         <input type="radio" onChange={handleChange} name='ACHIVE' value="gold"/> gold
         <br/>
         </label>
        <button type='submit'>submit</button>
      </form>
    </>
  )
}

export default Form