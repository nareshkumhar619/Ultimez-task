
import './App.css';
import {useEffect,useState} from "react"
import Form from './Component/Form';

function App() {

const [Fetch, setFetch] = useState([])

const API ="https://jsonplaceholder.typicode.com/users"

const fetchuser =async (url) => {
    try {
      const res = await fetch(url)
      const data = await res.json()
      setFetch(data)
      console.log(data)
    } catch (err) {
      console.log("error")
    }
}

useEffect(() => {
   fetchuser(API)
}, [])



// useEffect(() => {
//     fetch("https://jsonplaceholder.typicode.com/users")
//   .then((data) =>{data.json()  
//   .then((json) => {
//     setFetch(json)
//   })
// })  
// }, [])
// console.log(Fetch)


  return (
    <>
     {/* <Form/> */}
     <h1>Api calls</h1>
     <table>
      {
        Fetch.map((ele , id)=>{
          return (
            <thead key={id}>
            <tr >
            <td>{ele.id}</td>
            <td>{ele.name}</td>
            <td>{ele.username}</td>
            </tr>
            </thead>
          )
        })
      }
    
     </table>
    </>
  );
}

export default App;
